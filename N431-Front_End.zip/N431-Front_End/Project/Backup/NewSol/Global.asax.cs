﻿using System.Web;

namespace NewSol
{
    public class Global : HttpApplication
    {
        protected void Application_Start()
        {
        }
    }
}
