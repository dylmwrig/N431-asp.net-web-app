Just a txt file
